package com.example.model

import android.net.Uri

data class ConvertedAudio(
    val id: Long,
    val name: String,
    val durationMs: Long,
    val sizeBytes: Long,
    val path: String,
    val uri: Uri
)
