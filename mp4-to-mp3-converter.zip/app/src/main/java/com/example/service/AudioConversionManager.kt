package com.example.service

import android.net.Uri
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

sealed class ConversionStatus {
    object Idle : ConversionStatus()
    object Copying : ConversionStatus()
    object Converting : ConversionStatus()
    data class Success(val originalName: String, val resultUri: Uri) : ConversionStatus()
    data class Error(val message: String) : ConversionStatus()
}

object AudioConversionManager {
    private val _progress = MutableStateFlow<Int?>(null)
    val progress: StateFlow<Int?> = _progress.asStateFlow()

    private val _status = MutableStateFlow<ConversionStatus>(ConversionStatus.Idle)
    val status: StateFlow<ConversionStatus> = _status.asStateFlow()

    fun setProgress(value: Int?) {
        _progress.value = value
    }

    fun setStatus(value: ConversionStatus) {
        _status.value = value
    }

    fun reset() {
        _progress.value = null
        _status.value = ConversionStatus.Idle
    }
}
