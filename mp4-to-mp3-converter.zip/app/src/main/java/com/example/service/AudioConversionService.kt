package com.example.service

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.IBinder
import android.provider.MediaStore
import android.util.Log
import androidx.core.app.NotificationCompat
import io.microshow.rxffmpeg.RxFFmpegInvoke.IFFmpegListener
import io.microshow.rxffmpeg.RxFFmpegInvoke
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import java.io.File

class AudioConversionService : Service() {

    private val job = SupervisorJob()
    private val serviceScope = CoroutineScope(Dispatchers.IO + job)

    companion object {
        private const val TAG = "AudioConversionService"
        private const val CHANNEL_ID = "audio_conversion_channel"
        private const val NOTIFICATION_ID = 4882
        
        const val EXTRA_INPUT_URI = "input_uri"
        const val EXTRA_DISPLAY_NAME = "display_name"
    }

    override fun onCreate() {
        super.onCreate()
        createNotificationChannel()
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent != null) {
            val inputUriString = intent.getStringExtra(EXTRA_INPUT_URI)
            val displayName = intent.getStringExtra(EXTRA_DISPLAY_NAME) ?: "converted_audio.mp3"
            
            if (inputUriString != null) {
                val inputUri = Uri.parse(inputUriString)
                serviceScope.launch {
                    performConversion(inputUri, displayName)
                }
            } else {
                Log.e(TAG, "Input Uri is missing in service start intent.")
                stopSelf()
            }
        } else {
            stopSelf()
        }
        return START_NOT_STICKY
    }

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID,
                "MP4 to MP3 Converter Status",
                NotificationManager.IMPORTANCE_LOW
            ).apply {
                description = "Shows progress and state of active audio conversion tasks."
            }
            val manager = getSystemService(NotificationManager::class.java)
            manager?.createNotificationChannel(channel)
        }
    }

    private fun buildNotification(progress: Int, fileName: String): Notification {
        val titleText = if (progress >= 100) "Conversion Completed" else "Converting to MP3"
        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setContentTitle(titleText)
            .setContentText(fileName)
            .setSmallIcon(android.R.drawable.stat_sys_download)
            .setOngoing(progress < 100)
            .setOnlyAlertOnce(true)

        if (progress in 0..99) {
            builder.setProgress(100, progress, false)
            builder.setContentText("$fileName ($progress%)")
        } else if (progress == -1) {
            builder.setProgress(100, 0, true) // Indeterminate
        } else {
            builder.setProgress(0, 0, false)
            builder.setSmallIcon(android.R.drawable.stat_sys_download_done)
        }

        return builder.build()
    }

    private fun updateNotification(progress: Int, fileName: String) {
        val manager = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        manager.notify(NOTIFICATION_ID, buildNotification(progress, fileName))
    }

    private fun performConversion(inputUri: Uri, displayName: String) {
        val finalMp3Name = if (displayName.endsWith(".mp3", ignoreCase = true)) {
            displayName
        } else {
            "${displayName.substringBeforeLast(".")}.mp3"
        }

        // 1. Update status to copying
        AudioConversionManager.setStatus(ConversionStatus.Copying)
        AudioConversionManager.setProgress(0)

        // Starting foreground service properly based on API level
        val initialNotification = buildNotification(-1, finalMp3Name)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            startForeground(
                NOTIFICATION_ID,
                initialNotification,
                ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
            )
        } else {
            startForeground(NOTIFICATION_ID, initialNotification)
        }

        // 2. Copy the video Uri into a temporary file in app storage
        val tempInputFile = File(cacheDir, "temp_input_video_${System.currentTimeMillis()}.mp4")
        try {
            contentResolver.openInputStream(inputUri)?.use { inputStream ->
                tempInputFile.outputStream().use { outputStream ->
                    inputStream.copyTo(outputStream)
                }
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error copying input uri: ${e.message}", e)
            AudioConversionManager.setStatus(ConversionStatus.Error("Failed to access picked video file: ${e.localizedMessage}"))
            stopSelf()
            return
        }

        // 3. Define output path
        val tempOutputFile = File(cacheDir, "temp_output_audio_${System.currentTimeMillis()}.mp3")
        if (tempOutputFile.exists()) {
            tempOutputFile.delete()
        }

        // 4. Update status to active converting
        AudioConversionManager.setStatus(ConversionStatus.Converting)
        AudioConversionManager.setProgress(0)
        updateNotification(0, finalMp3Name)

        // 5. Construct FFmpeg commands
        // Command: -y -i <input> -vn -acodec libmp3lame -ar 44100 -ac 2 -b:a 192k <output>
        val commands = arrayOf(
            "ffmpeg",
            "-y",
            "-i", tempInputFile.absolutePath,
            "-vn",
            "-acodec", "libmp3lame",
            "-ar", "44100",
            "-ac", "2",
            "-b:a", "192k",
            tempOutputFile.absolutePath
        )

        try {
            RxFFmpegInvoke.getInstance().runCommand(commands, object : IFFmpegListener {
                override fun onFinish() {
                    Log.d(TAG, "FFmpeg processing finished successfully.")
                    
                    // Cleanup raw temporary input file immediately
                    if (tempInputFile.exists()) tempInputFile.delete()

                    // Save raw converted output MP3 directly to MediaStore
                    val resultUri = saveMp3ToMediaStore(tempOutputFile, finalMp3Name)
                    if (tempOutputFile.exists()) tempOutputFile.delete()

                    if (resultUri != null) {
                        AudioConversionManager.setProgress(100)
                        AudioConversionManager.setStatus(ConversionStatus.Success(finalMp3Name, resultUri))
                        updateNotification(100, finalMp3Name)
                    } else {
                        AudioConversionManager.setStatus(ConversionStatus.Error("Failed to save encoded audio to Public Music library."))
                    }
                    stopSelf()
                }

                override fun onProgress(progress: Int, progressTime: Long) {
                    val clampedProgress = progress.coerceIn(0, 100)
                    Log.d(TAG, "FFmpeg Progress: $clampedProgress%")
                    AudioConversionManager.setProgress(clampedProgress)
                    updateNotification(clampedProgress, finalMp3Name)
                }

                override fun onCancel() {
                    Log.d(TAG, "FFmpeg processing cancelled by user/OS.")
                    if (tempInputFile.exists()) tempInputFile.delete()
                    if (tempOutputFile.exists()) tempOutputFile.delete()
                    AudioConversionManager.reset()
                    stopSelf()
                }

                override fun onError(message: String?) {
                    Log.e(TAG, "FFmpeg conversion error: $message")
                    if (tempInputFile.exists()) tempInputFile.delete()
                    if (tempOutputFile.exists()) tempOutputFile.delete()
                    val errorMsg = message ?: "Unsupported codec, profile format or corrupted file."
                    AudioConversionManager.setStatus(ConversionStatus.Error(errorMsg))
                    stopSelf()
                }
            })
        } catch (e: Exception) {
            Log.e(TAG, "Error executing FFmpeg command: ${e.message}", e)
            if (tempInputFile.exists()) tempInputFile.delete()
            if (tempOutputFile.exists()) tempOutputFile.delete()
            AudioConversionManager.setStatus(ConversionStatus.Error("Conversion system error: ${e.localizedMessage}"))
            stopSelf()
        }
    }

    private fun saveMp3ToMediaStore(tempFile: File, finalName: String): Uri? {
        val values = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, finalName)
            put(MediaStore.Audio.Media.MIME_TYPE, "audio/mpeg")
            put(MediaStore.Audio.Media.DATE_ADDED, System.currentTimeMillis() / 1000)
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.Audio.Media.RELATIVE_PATH, "${Environment.DIRECTORY_MUSIC}/Converted Audio")
                put(MediaStore.Audio.Media.IS_PENDING, 1)
            }
        }

        val resolver = contentResolver
        val uri = resolver.insert(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, values) ?: return null

        return try {
            resolver.openOutputStream(uri)?.use { outputStream ->
                tempFile.inputStream().use { inputStream ->
                    inputStream.copyTo(outputStream)
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                values.clear()
                values.put(MediaStore.Audio.Media.IS_PENDING, 0)
                resolver.update(uri, values, null, null)
            }
            uri
        } catch (e: Exception) {
            Log.e(TAG, "Failed copy to media store: ${e.message}", e)
            resolver.delete(uri, null, null)
            null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        job.cancel()
    }
}
