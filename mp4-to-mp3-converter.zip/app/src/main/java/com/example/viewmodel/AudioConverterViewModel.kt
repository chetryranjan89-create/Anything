package com.example.viewmodel

import android.content.ContentUris
import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.ConvertedAudio
import com.example.service.AudioConversionManager
import com.example.service.ConversionStatus
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.io.File
import java.text.DecimalFormat

class AudioConverterViewModel : ViewModel() {

    private val _libraryList = MutableStateFlow<List<ConvertedAudio>>(emptyList())
    val libraryList: StateFlow<List<ConvertedAudio>> = _libraryList.asStateFlow()

    // Playback state
    private val _playingTrack = MutableStateFlow<ConvertedAudio?>(null)
    val playingTrack: StateFlow<ConvertedAudio?> = _playingTrack.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _playbackPosition = MutableStateFlow(0L)
    val playbackPosition: StateFlow<Long> = _playbackPosition.asStateFlow()

    private val _playbackDuration = MutableStateFlow(0L)
    val playbackDuration: StateFlow<Long> = _playbackDuration.asStateFlow()

    private var mediaPlayer: MediaPlayer? = null
    private var progressJob: Job? = null

    companion object {
        private const val TAG = "AudioConverterViewModel"
    }

    init {
        // Observe conversion completion to auto-reload
        viewModelScope.launch {
            AudioConversionManager.status.collect { status ->
                if (status is ConversionStatus.Success) {
                    // Slight delay to allow MediaStore scanner to register fully
                    delay(800)
                    _playingTrack.value = null // reset player just in case
                }
            }
        }
    }

    fun loadFiles(context: Context) {
        viewModelScope.launch(Dispatchers.IO) {
            val audioList = mutableListOf<ConvertedAudio>()
            val projection = arrayOf(
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.DISPLAY_NAME,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.SIZE,
                MediaStore.Audio.Media.DATA
            )

            // Query only files saved in standard-compliant directory path
            val selection = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                "${MediaStore.Audio.Media.RELATIVE_PATH} LIKE ?"
            } else {
                "${MediaStore.Audio.Media.DATA} LIKE ?"
            }

            val selectionArgs = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                arrayOf("%Music/Converted Audio%")
            } else {
                arrayOf("%Converted Audio%")
            }

            val sortOrder = "${MediaStore.Audio.Media.DATE_ADDED} DESC"

            try {
                context.contentResolver.query(
                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    projection,
                    selection,
                    selectionArgs,
                    sortOrder
                )?.use { cursor ->
                    val idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                    val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                    val durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                    val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                    val pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)

                    while (cursor.moveToNext()) {
                        val id = if (idCol != -1) cursor.getLong(idCol) else 0L
                        val name = if (nameCol != -1) cursor.getString(nameCol) ?: "Unknown" else "Unknown"
                        val duration = if (durationCol != -1) cursor.getLong(durationCol) else 0L
                        val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                        val path = if (pathCol != -1) cursor.getString(pathCol) ?: "" else ""
                        val contentUri = ContentUris.withAppendedId(
                            MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                            id
                        )

                        audioList.add(ConvertedAudio(id, name, duration, size, path, contentUri))
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error querying MediaStore: ${e.message}", e)
            }

            // Fallback: If no files in "Music/Converted Audio" let's scan matching prefix/extension just to satisfy retro displays
            if (audioList.isEmpty()) {
                val fallbackSelection = "${MediaStore.Audio.Media.DISPLAY_NAME} LIKE ?"
                val fallbackArgs = arrayOf("%.mp3%")
                try {
                    context.contentResolver.query(
                        MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                        projection,
                        fallbackSelection,
                        fallbackArgs,
                        sortOrder
                    )?.use { cursor ->
                        val idCol = cursor.getColumnIndex(MediaStore.Audio.Media._ID)
                        val nameCol = cursor.getColumnIndex(MediaStore.Audio.Media.DISPLAY_NAME)
                        val durationCol = cursor.getColumnIndex(MediaStore.Audio.Media.DURATION)
                        val sizeCol = cursor.getColumnIndex(MediaStore.Audio.Media.SIZE)
                        val pathCol = cursor.getColumnIndex(MediaStore.Audio.Media.DATA)

                        while (cursor.moveToNext()) {
                            val id = if (idCol != -1) cursor.getLong(idCol) else 0L
                            val name = if (nameCol != -1) cursor.getString(nameCol) ?: "Unknown" else "Unknown"
                            val path = if (pathCol != -1) cursor.getString(pathCol) ?: "" else ""
                            
                            if (path.contains("Converted Audio", ignoreCase = true)) {
                                val duration = if (durationCol != -1) cursor.getLong(durationCol) else 0L
                                val size = if (sizeCol != -1) cursor.getLong(sizeCol) else 0L
                                val contentUri = ContentUris.withAppendedId(
                                    MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                                    id
                                )
                                audioList.add(ConvertedAudio(id, name, duration, size, path, contentUri))
                            }
                        }
                    }
                } catch (e: Exception) {
                    Log.e(TAG, "Fallback MediaStore query error: ${e.message}", e)
                }
            }

            _libraryList.value = audioList
        }
    }

    // PLAYBACK API
    fun playTrack(context: Context, track: ConvertedAudio) {
        if (mediaPlayer != null) {
            mediaPlayer?.release()
            mediaPlayer = null
        }
        progressJob?.cancel()

        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(context, track.uri)
                prepare()
                start()
                setOnCompletionListener {
                    _isPlaying.value = false
                    _playbackPosition.value = 0L
                    progressJob?.cancel()
                }
            }
            _playingTrack.value = track
            _isPlaying.value = true
            _playbackDuration.value = mediaPlayer?.duration?.toLong() ?: 0L
            _playbackPosition.value = 0L

            startProgressUpdates()
        } catch (e: Exception) {
            Log.e(TAG, "Error playing audio index: ${e.message}", e)
        }
    }

    fun togglePlayPause() {
        val player = mediaPlayer ?: return
        if (player.isPlaying) {
            player.pause()
            _isPlaying.value = false
        } else {
            player.start()
            _isPlaying.value = true
            startProgressUpdates()
        }
    }

    fun seekTo(positionMs: Long) {
        val player = mediaPlayer ?: return
        player.seekTo(positionMs.toInt())
        _playbackPosition.value = positionMs
    }

    fun skipAhead() {
        val player = mediaPlayer ?: return
        val target = (player.currentPosition + 10000).coerceAtMost(player.duration)
        player.seekTo(target)
        _playbackPosition.value = target.toLong()
    }

    fun skipBack() {
        val player = mediaPlayer ?: return
        val target = (player.currentPosition - 10000).coerceAtLeast(0)
        player.seekTo(target)
        _playbackPosition.value = target.toLong()
    }

    private fun startProgressUpdates() {
        progressJob?.cancel()
        progressJob = viewModelScope.launch {
            while (true) {
                val player = mediaPlayer
                if (player != null && player.isPlaying) {
                    _playbackPosition.value = player.currentPosition.toLong()
                }
                delay(300)
            }
        }
    }

    // LIBRARY MUTATIONS
    fun renameTrack(context: Context, track: ConvertedAudio, newCleanName: String): Boolean {
        val finalName = if (newCleanName.endsWith(".mp3", ignoreCase = true)) {
            newCleanName
        } else {
            "$newCleanName.mp3"
        }

        val contentValues = ContentValues().apply {
            put(MediaStore.Audio.Media.DISPLAY_NAME, finalName)
        }

        return try {
            val updated = context.contentResolver.update(track.uri, contentValues, null, null) > 0
            if (updated) {
                // If it's the currently playing audio, update metadata
                if (_playingTrack.value?.id == track.id) {
                    _playingTrack.value = _playingTrack.value?.copy(name = finalName)
                }
                loadFiles(context)
            }
            updated
        } catch (e: Exception) {
            Log.e(TAG, "Failed renaming media track: ${e.message}", e)
            false
        }
    }

    fun shareTrack(context: Context, track: ConvertedAudio) {
        try {
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/mpeg"
                putExtra(Intent.EXTRA_STREAM, track.uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                putExtra(Intent.EXTRA_TITLE, track.name)
            }
            val chooser = Intent.createChooser(intent, "Share MP3 Audio File")
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Log.e(TAG, "Failed sharing media track: ${e.message}", e)
        }
    }

    fun deleteTrack(context: Context, track: ConvertedAudio): Boolean {
        return try {
            // If deleting the active playing track, release player first
            if (_playingTrack.value?.id == track.id) {
                if (mediaPlayer != null) {
                    mediaPlayer?.release()
                    mediaPlayer = null
                }
                _playingTrack.value = null
                _isPlaying.value = false
                _playbackPosition.value = 0L
                progressJob?.cancel()
            }

            val deleted = context.contentResolver.delete(track.uri, null, null) > 0
            if (deleted) {
                loadFiles(context)
            }
            deleted
        } catch (e: Exception) {
            Log.e(TAG, "Failed deleting media track inside MediaStore: ${e.message}", e)
            false
        }
    }

    fun formatDuration(ms: Long): String {
        if (ms <= 0) return "00:00"
        val totalSeconds = ms / 1000
        val minutes = totalSeconds / 60
        val seconds = totalSeconds % 60
        return String.format("%02d:%02d", minutes, seconds)
    }

    fun formatSize(bytes: Long): String {
        if (bytes <= 0) return "0 B"
        val df = DecimalFormat("#.#")
        return when {
            bytes >= 1024 * 1024 * 1024 -> df.format(bytes / (1024.0 * 1024.0 * 1024.0)) + " GB"
            bytes >= 1024 * 1024 -> df.format(bytes / (1024.0 * 1024.0)) + " MB"
            bytes >= 1024 -> df.format(bytes / 1024.0) + " KB"
            else -> "$bytes B"
        }
    }

    override fun onCleared() {
        super.onCleared()
        mediaPlayer?.release()
        mediaPlayer = null
        progressJob?.cancel()
    }
}
